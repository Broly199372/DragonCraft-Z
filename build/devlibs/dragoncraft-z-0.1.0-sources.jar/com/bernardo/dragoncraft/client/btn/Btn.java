package com.bernardo.dragoncraft.client.btn;

import com.bernardo.dragoncraft.DragonCraft;
import net.minecraft.resource.ResourceLocation;



public interface Btn {
    void onClick();

    int U();
    int V();

    int W();
    int H();
    
    int pressedU();
    int pressedV();
    
    
    public static final ResourceLocation getTexture() {
        return new ResourceLocation(DragonCraft.MOD_ID, "textures/gui/icons");
    }

    void render(int U, int V, int W, int H, int pressedU, int pressedV, int mouseX, int mouseY, boolean isPressed);


}