package com.bernardo.dragoncraft.mixin;

import com.bernardo.dragoncraft.core.KiManager;
import com.bernardo.dragoncraft.core.KiSystem;
import com.bernardo.dragoncraft.core.data.PlayerKiData;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin para salvar e carregar dados de Ki no NBT do jogador.
 * 
 * IMPORTANTE: Este arquivo DEVE ser Java (.java), NÃO Kotlin (.kt)!
 * Mixins em Kotlin são incompatíveis com SpongePowered Mixin.
 * 
 * Injeta nos métodos writeCustomDataToNbt e readCustomDataFromNbt
 * do PlayerEntity para persistir os dados de Ki entre sessões.
 */
@Mixin(class_1657.class)
public abstract class PlayerDataMixin {

    /**
     * Salva dados de Ki quando o jogador é salvo no mundo.
     * Chamado automaticamente ao sair, ao salvar o mundo, etc.
     */
    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void dragoncraft$saveKiData(class_2487 nbt, CallbackInfo ci) {
        class_1657 player = (class_1657) (Object) this;
        PlayerKiData data = KiManager.INSTANCE.getPlayerKiDataOrNull(player.method_5667());
        if (data != null) {
            class_2487 kiNbt = new class_2487();
            data.writeToNbt(kiNbt);
            nbt.method_10566("DragonCraftKi", kiNbt);
        }
    }

    /**
     * Carrega dados de Ki quando o jogador é carregado do mundo.
     * Chamado automaticamente ao entrar no mundo, ao respawnar, etc.
     */
    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void dragoncraft$loadKiData(class_2487 nbt, CallbackInfo ci) {
        class_1657 player = (class_1657) (Object) this;
        if (nbt.method_10545("DragonCraftKi")) {
            class_2487 kiNbt = nbt.method_10562("DragonCraftKi");
            PlayerKiData data = new PlayerKiData();
            data.readFromNbt(kiNbt);
            KiManager.INSTANCE.setPlayerKiData(player, data);
            KiSystem.INSTANCE.validateData(data);
        }
    }
}
