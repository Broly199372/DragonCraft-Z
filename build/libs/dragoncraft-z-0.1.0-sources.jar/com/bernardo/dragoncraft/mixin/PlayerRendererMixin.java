package com.bernardo.dragoncraft.mixin;

import com.bernardo.dragoncraft.client.aura.AuraRenderer;
import com.bernardo.dragoncraft.core.KiManager;
import com.bernardo.dragoncraft.core.data.PlayerKiData;
import net.minecraft.class_1007;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public class PlayerRendererMixin {

    @Inject(
        method = "render",
        at = @At("TAIL")
    )
    private void dragoncraft$renderAura(class_742 player,
                                        float yaw,
                                        float tickDelta,
                                        class_4587 matrices,
                                        class_4597 provider,
                                        int light,
                                        CallbackInfo ci) {

        PlayerKiData data = KiManager.INSTANCE.getPlayerKiDataOrNull(player.method_5667());
        if (data == null || !data.getAuraActive()) return;

        AuraRenderer.render(matrices, provider, player, tickDelta, light);
    }
}
