package com.bernardo.dragoncraft.client.btn;

import com.bernardo.dragoncraft.DragonCraftZ;
import net.minecraft.class_2960;

public interface Btn {
    void onClick();

    int U();
    int V();
    int W();
    int H();
    int pressedU();
    int pressedV();

    class_2960 BTN_TEXTURE = new class_2960(DragonCraftZ.MOD_ID, "textures/gui/icons.png");

    void render(int U, int V, int W, int H, int pressedU, int pressedV,
                int mouseX, int mouseY, boolean isPressed);
}
