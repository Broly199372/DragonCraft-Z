package com.bernardo.dragoncraft.client.aura;

import com.bernardo.dragoncraft.DragonCraftZ;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;

public class AuraRenderer {

    private static final class_2960 AURA_TEXTURE =
        new class_2960(DragonCraftZ.MOD_ID, "textures/entity/aura.png");

    // 6 layers: [escala, opacidade, velocidade de rotação, cor 0=dourado 1=azul]
    private static final float[][] LAYERS = {
        { 0.55f, 0.35f,  0.8f, 0 },  // layer 1 - dourado, interno, mais denso
        { 0.70f, 0.28f, -1.0f, 1 },  // layer 2 - azul, gira ao contrário
        { 0.85f, 0.20f,  1.3f, 0 },  // layer 3 - dourado, médio
        { 1.00f, 0.15f, -0.7f, 1 },  // layer 4 - azul, médio-externo
        { 1.20f, 0.10f,  0.5f, 0 },  // layer 5 - dourado, externo
        { 1.40f, 0.08f, -0.4f, 1 },  // layer 6 - azul, mais externo, quase sumindo
    };

    // Oval: largura menor que altura pra abraçar o corpo
    private static final float OVAL_W = 0.55f;
    private static final float OVAL_H = 1.10f;

    public static void render(class_4587 matrices,
                              class_4597 provider,
                              class_1657 player,
                              float tickDelta,
                              int light) {

        float time = (player.field_6012 + tickDelta) * 0.05f;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(false);

        class_4588 buffer = provider.getBuffer(
            class_1921.method_23689(AURA_TEXTURE)
        );

        matrices.method_22903();
        // Centraliza no meio do corpo
        matrices.method_22904(0.0, 1.0, 0.0);

        for (float[] layer : LAYERS) {
            float scale    = layer[0];
            float alpha    = layer[1];
            float speed    = layer[2];
            boolean isBlue = layer[3] == 1;

            // Pulso suave e único por layer
            float pulse = 1.0f + 0.06f * class_3532.method_15374(time * 3.0f + scale * 5f);

            matrices.method_22903();

            // Rotação lenta no eixo Y
            float angle = time * speed * 20f;
            matrices.method_22907(net.minecraft.class_7833.field_40716
                .rotationDegrees(angle));

            float finalScale = scale * pulse;
            matrices.method_22905(finalScale, finalScale, finalScale);

            // Cor: dourado ou azul Ki
            float r, g, b;
            if (isBlue) {
                r = 0.25f; g = 0.55f; b = 1.00f;
            } else {
                r = 1.00f; g = 0.80f; b = 0.10f;
            }

            // Desenha 2 quads cruzados (X e Z) pra dar volume sem billboard completo
            drawOvalQuad(matrices, buffer, OVAL_W, OVAL_H, r, g, b, alpha, light, 0f);
            drawOvalQuad(matrices, buffer, OVAL_W, OVAL_H, r, g, b, alpha * 0.7f, light, 90f);

            matrices.method_22909();
        }

        matrices.method_22909();

        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
    }

    private static void drawOvalQuad(class_4587 matrices, class_4588 buffer,
                                     float w, float h,
                                     float r, float g, float b, float a,
                                     int light, float extraRotDeg) {

        matrices.method_22903();
        matrices.method_22907(net.minecraft.class_7833.field_40716
            .rotationDegrees(extraRotDeg));

        Matrix4f m = matrices.method_23760().method_23761();

        int ri = (int)(r * 255);
        int gi = (int)(g * 255);
        int bi = (int)(b * 255);
        int ai = (int)(class_3532.method_15363(a, 0f, 1f) * 255);

        float top    =  h * 0.5f;
        float bottom = -h * 0.5f;

        // Quad oval: vértices com UV pra usar o gradiente da textura
        buffer.method_22918(m, -w, bottom, 0).method_1336(ri, gi, bi, 0 ).method_22913(0f, 1f).method_22916(light).method_1344();
        buffer.method_22918(m,  w, bottom, 0).method_1336(ri, gi, bi, 0 ).method_22913(1f, 1f).method_22916(light).method_1344();
        buffer.method_22918(m,  w, top,    0).method_1336(ri, gi, bi, ai).method_22913(1f, 0f).method_22916(light).method_1344();
        buffer.method_22918(m, -w, top,    0).method_1336(ri, gi, bi, ai).method_22913(0f, 0f).method_22916(light).method_1344();
    }
}
